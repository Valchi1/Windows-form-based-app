﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VALCHI_CAR_RENTAL
{
    class models
    {
        DBConfig con = new DBConfig();
        DataTable dt = new DataTable();
        string expmessage = "";
        public string RegAccount(string fname, string lname, string address, int age, string license, int number, string cartype, string fueltype, string extras)
        {
            int k;
    
            string procedurename = "insertvalues";
            string connectionstr = con.connection();
            SqlConnection sqlcon = new SqlConnection(connectionstr);
            SqlCommand cmd = new SqlCommand(procedurename, sqlcon);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@firstname", fname);
            cmd.Parameters.AddWithValue("@lastname", lname);
            cmd.Parameters.AddWithValue("@address", address);
            cmd.Parameters.AddWithValue("@age", age);
            cmd.Parameters.AddWithValue("@license", license);
            cmd.Parameters.AddWithValue("@numberdays", number);
            cmd.Parameters.AddWithValue("@cartype", cartype);
            cmd.Parameters.AddWithValue("@fueltype", fueltype);
            cmd.Parameters.AddWithValue("@extras", extras);

            sqlcon.Open();
            k = cmd.ExecuteNonQuery();
            sqlcon.Close();
            if(k== -1)
            {
                expmessage = "successful";

            }
            return expmessage;
        }


    }
}
