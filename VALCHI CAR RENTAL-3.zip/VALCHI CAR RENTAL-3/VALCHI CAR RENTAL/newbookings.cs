﻿
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace VALCHI_CAR_RENTAL
{
    public partial class newbookings : Form
    {
        public static string CFN = "";
        public static string CSN = "";
        public static string CADDY = "";
        public static string CAGE = "";
        public static string VDL = "";
        public static string NOD = "";
        public static string CT = "";
        public static string FT = "";
        public static string OE = "";

       
        
        string mileage;
        string breakdown;


        public newbookings()
        {
            InitializeComponent();
        }
        
        
            private void label2_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {




        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            
            
        }

        private void radioButton9_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            firstname_txtbox.Text = "";
            surname_txtbox.Text = "";
            address_txtbox.Text = "";
            age_txtbox.Text = "";
            yes_rdobtn.Checked = false;
            no_rdobtn.Checked = false;
            numericUpDown1.Value = 0;
            citycar_rdobtn.Checked = false;
            famcar_rdobtn.Checked = false;
            sports_rdobtn.Checked = false;
            suv_rdobtn.Checked = false;
            petrol_rdobtn.Checked = false;
            diesel_rdobtn.Checked = false;
            hybrid_rdobtn.Checked = false;
            electric_rdobtn.Checked = false;
            milleagecheckbox.Checked= false;
            breakdowncheckbox.Checked = false;
        }

        private void no_rdobtn_CheckedChanged(object sender, EventArgs e)
        {
            if (no_rdobtn.Checked == true)
            {
                MessageBox.Show("cannot proceed without a valid driving liscense");

                Home_Page goTO = new Home_Page();
                goTO.Show();
                this.Close();
                liscense_lbl.Text = "no";
            }
            else if (yes_rdobtn.Checked == true)
            {
                liscense_lbl.Text = "yes";
            }
        }

        private void Submitbtn_Click(object sender, EventArgs e)
        {

            string firstname = firstname_txtbox.Text;
            string surname = surname_txtbox.Text;
            string customeraddress = address_txtbox.Text;
            string customerage = age_txtbox.Text;
            string validdrivingliscence = liscense_lbl.Text;
            string Numberofdays = numericUpDown1.Text;
            string cartype = cartypebox.Text;
            string fueltype = groupBox3.Text;
            string mileage = milleagecheckbox.Checked.ToString();
            string brekadown = breakdowncheckbox.Checked.ToString();

            

            //string cartype=
            // insert submit button comment here 

            string sfueltype = groupBox3.Text;
            if (petrol_rdobtn.Checked == true)
            {
                fueltype = "Petrol";

            }
            else if (diesel_rdobtn.Checked == true)
            {
                fueltype = "Diesel";
            }
            else if (hybrid_rdobtn.Checked == true)
            {
                fueltype = "Hybrid";

            }
            else if (electric_rdobtn.Checked == true)
            {
                fueltype = "Electric";
            }

            string scartype = cartypebox.Text;
            if (citycar_rdobtn.Checked == true)
            {
                cartype = "City car";
            }
            else if (famcar_rdobtn.Checked == true)
            {
                cartype = " Family Car";
            }
            else if (sports_rdobtn.Checked == true)
            {
                cartype = "Sports Car";
            }

            else if (suv_rdobtn.Checked == true)
            {
                cartype = "SUV";
            }

            CFN = firstname;
            CSN = surname;
            CADDY = customeraddress;
            CAGE = customerage;
            VDL = validdrivingliscence;
            NOD = Numberofdays;
            CT = cartype;
            FT = fueltype;
            OE = mileage + brekadown;

            

                if (firstname_txtbox.Text == "" || surname_txtbox.Text == "" ||address_txtbox.Text == "" || age_txtbox.Text == "" || yes_rdobtn.Checked == false || cartypebox.Text == "" || groupBox3.Text == ""  || groupBox4.Text == "")
            {
                MessageBox.Show("Missing Information");
            }
           else
            {
                this.Close();
                summary goTo = new summary();
                goTo.Show();
            }
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void suv_rdobtn_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void surname_txtbox_TextChanged(object sender, EventArgs e)
        {

        }

        private void firstname_txtbox_TextChanged(object sender, EventArgs e)
        {

        }

        private void add_btn_Click(object sender, EventArgs e)
        {
            
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void electric_rdobtn_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void yes_rdobtn_CheckedChanged(object sender, EventArgs e)
        {
           
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
         /*  if (_== true)
            {
                mileagecheckbox = "Yes";
            }
            else 
                {
                milleagecheckbox = "N/A";
            } */ 
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            
        }

        private void petrol_rdobtn_CheckedChanged(object sender, EventArgs e)
        {
            
        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {
           
        }

        private void groupBox4_Enter(object sender, EventArgs e)
        {
          
        }

        private void groupBox3_Enter(object sender, EventArgs e)
        {

        }
    }
}
