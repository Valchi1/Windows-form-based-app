﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VALCHI_CAR_RENTAL
{
    public partial class Home_Page : Form
    {
        public Home_Page()
        {
            InitializeComponent();
        }

        private void Home_Page_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'database1DataSet.VALCHICARRENTAL' table. You can move, or remove it, as needed.
            this.vALCHICARRENTALTableAdapter.Fill(this.database1DataSet.VALCHICARRENTAL);



        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            DialogResult obj = MessageBox.Show("Do you want to exit?", "Exit", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (obj == DialogResult.Yes)
            {
                Application.Exit();
            }
            


                 

        }

        private void label2_Click_1(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e) //CODE TO ADD NEWBOOKINS
        {
            this.Close();
            newbookings goTo = new newbookings();
            goTo.Show();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            //CODE TO RETURN BACK HOME
            this.Close();
            Home_Page goTo = new Home_Page();
            goTo.Show();

        }

        private void button2_Click(object sender, EventArgs e)
        {
        
        }
    }
}
