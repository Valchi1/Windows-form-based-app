﻿
namespace VALCHI_CAR_RENTAL
{
    partial class newbookings
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.CheckBox mileagecheck;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(newbookings));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.firstname_txtbox = new System.Windows.Forms.TextBox();
            this.surname_txtbox = new System.Windows.Forms.TextBox();
            this.address_txtbox = new System.Windows.Forms.TextBox();
            this.age_txtbox = new System.Windows.Forms.TextBox();
            this.liscense_lbl = new System.Windows.Forms.Label();
            this.yes_rdobtn = new System.Windows.Forms.RadioButton();
            this.no_rdobtn = new System.Windows.Forms.RadioButton();
            this.label6 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lbladmin = new System.Windows.Forms.Label();
            this.cartypebox = new System.Windows.Forms.GroupBox();
            this.suv_rdobtn = new System.Windows.Forms.RadioButton();
            this.sports_rdobtn = new System.Windows.Forms.RadioButton();
            this.famcar_rdobtn = new System.Windows.Forms.RadioButton();
            this.citycar_rdobtn = new System.Windows.Forms.RadioButton();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.electric_rdobtn = new System.Windows.Forms.RadioButton();
            this.hybrid_rdobtn = new System.Windows.Forms.RadioButton();
            this.diesel_rdobtn = new System.Windows.Forms.RadioButton();
            this.petrol_rdobtn = new System.Windows.Forms.RadioButton();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.breakdowncheckbox = new System.Windows.Forms.CheckBox();
            this.clear_btn = new System.Windows.Forms.Button();
            this.Submitbtn = new System.Windows.Forms.Button();
            mileagecheck = new System.Windows.Forms.CheckBox();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.cartypebox.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.SuspendLayout();
            // 
            // mileagecheck
            // 
            mileagecheck.AutoSize = true;
            mileagecheck.Location = new System.Drawing.Point(6, 24);
            mileagecheck.Name = "mileagecheck";
            mileagecheck.Size = new System.Drawing.Size(177, 17);
            mileagecheck.TabIndex = 4;
            mileagecheck.Text = "Unlimited Mileage(+$10 per day)";
            mileagecheck.UseVisualStyleBackColor = true;
            mileagecheck.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(143, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "CUSTOMER FIRST NAME *";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 81);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(129, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "CUSTOMER SURNAME*";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 127);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(127, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "CUSTOMER ADDRESS*";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 183);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(97, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "CUSTOMER AGE*";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // firstname_txtbox
            // 
            this.firstname_txtbox.Location = new System.Drawing.Point(155, 29);
            this.firstname_txtbox.Name = "firstname_txtbox";
            this.firstname_txtbox.Size = new System.Drawing.Size(100, 20);
            this.firstname_txtbox.TabIndex = 4;
            this.firstname_txtbox.TextChanged += new System.EventHandler(this.firstname_txtbox_TextChanged);
            // 
            // surname_txtbox
            // 
            this.surname_txtbox.Location = new System.Drawing.Point(155, 74);
            this.surname_txtbox.Name = "surname_txtbox";
            this.surname_txtbox.Size = new System.Drawing.Size(100, 20);
            this.surname_txtbox.TabIndex = 5;
            this.surname_txtbox.TextChanged += new System.EventHandler(this.surname_txtbox_TextChanged);
            // 
            // address_txtbox
            // 
            this.address_txtbox.Location = new System.Drawing.Point(155, 127);
            this.address_txtbox.Name = "address_txtbox";
            this.address_txtbox.Size = new System.Drawing.Size(100, 20);
            this.address_txtbox.TabIndex = 6;
            // 
            // age_txtbox
            // 
            this.age_txtbox.Location = new System.Drawing.Point(155, 183);
            this.age_txtbox.Name = "age_txtbox";
            this.age_txtbox.Size = new System.Drawing.Size(100, 20);
            this.age_txtbox.TabIndex = 7;
            // 
            // liscense_lbl
            // 
            this.liscense_lbl.AutoSize = true;
            this.liscense_lbl.Location = new System.Drawing.Point(6, 242);
            this.liscense_lbl.Name = "liscense_lbl";
            this.liscense_lbl.Size = new System.Drawing.Size(111, 13);
            this.liscense_lbl.TabIndex = 8;
            this.liscense_lbl.Text = "Valid Driving Liscense";
            // 
            // yes_rdobtn
            // 
            this.yes_rdobtn.AutoSize = true;
            this.yes_rdobtn.Location = new System.Drawing.Point(155, 238);
            this.yes_rdobtn.Name = "yes_rdobtn";
            this.yes_rdobtn.Size = new System.Drawing.Size(43, 17);
            this.yes_rdobtn.TabIndex = 9;
            this.yes_rdobtn.TabStop = true;
            this.yes_rdobtn.Text = "Yes";
            this.yes_rdobtn.UseVisualStyleBackColor = true;
            this.yes_rdobtn.CheckedChanged += new System.EventHandler(this.yes_rdobtn_CheckedChanged);
            // 
            // no_rdobtn
            // 
            this.no_rdobtn.AutoSize = true;
            this.no_rdobtn.Location = new System.Drawing.Point(155, 261);
            this.no_rdobtn.Name = "no_rdobtn";
            this.no_rdobtn.Size = new System.Drawing.Size(39, 17);
            this.no_rdobtn.TabIndex = 10;
            this.no_rdobtn.TabStop = true;
            this.no_rdobtn.Text = "No";
            this.no_rdobtn.UseVisualStyleBackColor = true;
            this.no_rdobtn.CheckedChanged += new System.EventHandler(this.no_rdobtn_CheckedChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(-3, 319);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(147, 13);
            this.label6.TabIndex = 11;
            this.label6.Text = "Number Of Days($25 per day)";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.numericUpDown1);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.firstname_txtbox);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.no_rdobtn);
            this.groupBox1.Controls.Add(this.surname_txtbox);
            this.groupBox1.Controls.Add(this.yes_rdobtn);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.liscense_lbl);
            this.groupBox1.Controls.Add(this.address_txtbox);
            this.groupBox1.Controls.Add(this.age_txtbox);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Location = new System.Drawing.Point(0, 63);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(264, 380);
            this.groupBox1.TabIndex = 15;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "CUSTOMER DETAILS";
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Location = new System.Drawing.Point(155, 312);
            this.numericUpDown1.Maximum = new decimal(new int[] {
            28,
            0,
            0,
            0});
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(98, 20);
            this.numericUpDown1.TabIndex = 12;
            this.numericUpDown1.ValueChanged += new System.EventHandler(this.numericUpDown1_ValueChanged);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Black;
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.lbladmin);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(494, 57);
            this.panel1.TabIndex = 16;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.LightSeaGreen;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(3, 7);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(65, 34);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 6;
            this.pictureBox1.TabStop = false;
            // 
            // lbladmin
            // 
            this.lbladmin.AutoSize = true;
            this.lbladmin.Font = new System.Drawing.Font("Segoe UI Black", 13.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbladmin.ForeColor = System.Drawing.Color.White;
            this.lbladmin.Location = new System.Drawing.Point(154, 16);
            this.lbladmin.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbladmin.Name = "lbladmin";
            this.lbladmin.Size = new System.Drawing.Size(165, 25);
            this.lbladmin.TabIndex = 5;
            this.lbladmin.Text = "NEW BOOKINGS";
            // 
            // cartypebox
            // 
            this.cartypebox.Controls.Add(this.suv_rdobtn);
            this.cartypebox.Controls.Add(this.sports_rdobtn);
            this.cartypebox.Controls.Add(this.famcar_rdobtn);
            this.cartypebox.Controls.Add(this.citycar_rdobtn);
            this.cartypebox.Location = new System.Drawing.Point(283, 63);
            this.cartypebox.Name = "cartypebox";
            this.cartypebox.Size = new System.Drawing.Size(189, 123);
            this.cartypebox.TabIndex = 17;
            this.cartypebox.TabStop = false;
            this.cartypebox.Text = "CAR TYPE";
            this.cartypebox.Enter += new System.EventHandler(this.groupBox2_Enter);
            // 
            // suv_rdobtn
            // 
            this.suv_rdobtn.AutoSize = true;
            this.suv_rdobtn.Location = new System.Drawing.Point(7, 99);
            this.suv_rdobtn.Name = "suv_rdobtn";
            this.suv_rdobtn.Size = new System.Drawing.Size(77, 17);
            this.suv_rdobtn.TabIndex = 3;
            this.suv_rdobtn.TabStop = true;
            this.suv_rdobtn.Text = "SUV(+$65)";
            this.suv_rdobtn.UseVisualStyleBackColor = true;
            this.suv_rdobtn.CheckedChanged += new System.EventHandler(this.suv_rdobtn_CheckedChanged);
            // 
            // sports_rdobtn
            // 
            this.sports_rdobtn.AutoSize = true;
            this.sports_rdobtn.Location = new System.Drawing.Point(6, 75);
            this.sports_rdobtn.Name = "sports_rdobtn";
            this.sports_rdobtn.Size = new System.Drawing.Size(103, 17);
            this.sports_rdobtn.TabIndex = 2;
            this.sports_rdobtn.TabStop = true;
            this.sports_rdobtn.Text = "Sports car(+$75)";
            this.sports_rdobtn.UseVisualStyleBackColor = true;
            // 
            // famcar_rdobtn
            // 
            this.famcar_rdobtn.AutoSize = true;
            this.famcar_rdobtn.Location = new System.Drawing.Point(6, 51);
            this.famcar_rdobtn.Name = "famcar_rdobtn";
            this.famcar_rdobtn.Size = new System.Drawing.Size(96, 17);
            this.famcar_rdobtn.TabIndex = 1;
            this.famcar_rdobtn.TabStop = true;
            this.famcar_rdobtn.Text = "Family car(+50)";
            this.famcar_rdobtn.UseVisualStyleBackColor = true;
            // 
            // citycar_rdobtn
            // 
            this.citycar_rdobtn.AccessibleName = "";
            this.citycar_rdobtn.AutoSize = true;
            this.citycar_rdobtn.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.citycar_rdobtn.Location = new System.Drawing.Point(6, 28);
            this.citycar_rdobtn.Name = "citycar_rdobtn";
            this.citycar_rdobtn.Size = new System.Drawing.Size(142, 17);
            this.citycar_rdobtn.TabIndex = 0;
            this.citycar_rdobtn.TabStop = true;
            this.citycar_rdobtn.Text = "City car(No extra charge)";
            this.citycar_rdobtn.UseVisualStyleBackColor = true;
            this.citycar_rdobtn.CheckedChanged += new System.EventHandler(this.radioButton3_CheckedChanged);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.electric_rdobtn);
            this.groupBox3.Controls.Add(this.hybrid_rdobtn);
            this.groupBox3.Controls.Add(this.diesel_rdobtn);
            this.groupBox3.Controls.Add(this.petrol_rdobtn);
            this.groupBox3.Location = new System.Drawing.Point(283, 218);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(189, 123);
            this.groupBox3.TabIndex = 18;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "FUEL TYPE";
            this.groupBox3.Enter += new System.EventHandler(this.groupBox3_Enter);
            // 
            // electric_rdobtn
            // 
            this.electric_rdobtn.AutoSize = true;
            this.electric_rdobtn.Location = new System.Drawing.Point(7, 99);
            this.electric_rdobtn.Name = "electric_rdobtn";
            this.electric_rdobtn.Size = new System.Drawing.Size(109, 17);
            this.electric_rdobtn.TabIndex = 3;
            this.electric_rdobtn.TabStop = true;
            this.electric_rdobtn.Text = "Full Electric(+$50)";
            this.electric_rdobtn.UseVisualStyleBackColor = true;
            this.electric_rdobtn.CheckedChanged += new System.EventHandler(this.electric_rdobtn_CheckedChanged);
            // 
            // hybrid_rdobtn
            // 
            this.hybrid_rdobtn.AutoSize = true;
            this.hybrid_rdobtn.Location = new System.Drawing.Point(6, 75);
            this.hybrid_rdobtn.Name = "hybrid_rdobtn";
            this.hybrid_rdobtn.Size = new System.Drawing.Size(85, 17);
            this.hybrid_rdobtn.TabIndex = 2;
            this.hybrid_rdobtn.TabStop = true;
            this.hybrid_rdobtn.Text = "Hybrid(+$30)";
            this.hybrid_rdobtn.UseVisualStyleBackColor = true;
            // 
            // diesel_rdobtn
            // 
            this.diesel_rdobtn.AutoSize = true;
            this.diesel_rdobtn.Location = new System.Drawing.Point(6, 51);
            this.diesel_rdobtn.Name = "diesel_rdobtn";
            this.diesel_rdobtn.Size = new System.Drawing.Size(136, 17);
            this.diesel_rdobtn.TabIndex = 1;
            this.diesel_rdobtn.TabStop = true;
            this.diesel_rdobtn.Text = "Diesel(No extra charge)";
            this.diesel_rdobtn.UseVisualStyleBackColor = true;
            this.diesel_rdobtn.CheckedChanged += new System.EventHandler(this.radioButton9_CheckedChanged);
            // 
            // petrol_rdobtn
            // 
            this.petrol_rdobtn.AccessibleName = "";
            this.petrol_rdobtn.AutoSize = true;
            this.petrol_rdobtn.Location = new System.Drawing.Point(6, 28);
            this.petrol_rdobtn.Name = "petrol_rdobtn";
            this.petrol_rdobtn.Size = new System.Drawing.Size(134, 17);
            this.petrol_rdobtn.TabIndex = 0;
            this.petrol_rdobtn.TabStop = true;
            this.petrol_rdobtn.Text = "Petrol(No extra charge)";
            this.petrol_rdobtn.UseVisualStyleBackColor = true;
            this.petrol_rdobtn.CheckedChanged += new System.EventHandler(this.petrol_rdobtn_CheckedChanged);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(mileagecheck);
            this.groupBox4.Controls.Add(this.breakdowncheckbox);
            this.groupBox4.Location = new System.Drawing.Point(283, 352);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(189, 91);
            this.groupBox4.TabIndex = 19;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "OPTIONAL EXTRAS";
            this.groupBox4.Enter += new System.EventHandler(this.groupBox4_Enter);
            // 
            // breakdowncheckbox
            // 
            this.breakdowncheckbox.AutoSize = true;
            this.breakdowncheckbox.Location = new System.Drawing.Point(6, 53);
            this.breakdowncheckbox.Name = "breakdowncheckbox";
            this.breakdowncheckbox.Size = new System.Drawing.Size(172, 17);
            this.breakdowncheckbox.TabIndex = 5;
            this.breakdowncheckbox.Text = "Breakdown cover(+$2 per day)";
            this.breakdowncheckbox.UseVisualStyleBackColor = true;
            this.breakdowncheckbox.CheckedChanged += new System.EventHandler(this.checkBox2_CheckedChanged);
            // 
            // clear_btn
            // 
            this.clear_btn.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.clear_btn.Location = new System.Drawing.Point(119, 452);
            this.clear_btn.Name = "clear_btn";
            this.clear_btn.Size = new System.Drawing.Size(75, 23);
            this.clear_btn.TabIndex = 20;
            this.clear_btn.Text = "CLEAR";
            this.clear_btn.UseVisualStyleBackColor = false;
            this.clear_btn.Click += new System.EventHandler(this.button1_Click);
            // 
            // Submitbtn
            // 
            this.Submitbtn.BackColor = System.Drawing.Color.Black;
            this.Submitbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.Submitbtn.Location = new System.Drawing.Point(253, 452);
            this.Submitbtn.Name = "Submitbtn";
            this.Submitbtn.Size = new System.Drawing.Size(92, 23);
            this.Submitbtn.TabIndex = 21;
            this.Submitbtn.Text = "SUBMIT";
            this.Submitbtn.UseVisualStyleBackColor = false;
            this.Submitbtn.Click += new System.EventHandler(this.Submitbtn_Click);
            // 
            // newbookings
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(494, 487);
            this.Controls.Add(this.Submitbtn);
            this.Controls.Add(this.clear_btn);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.cartypebox);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.groupBox1);
            this.ForeColor = System.Drawing.Color.LightSeaGreen;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "newbookings";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "newbookings";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.cartypebox.ResumeLayout(false);
            this.cartypebox.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox firstname_txtbox;
        private System.Windows.Forms.TextBox surname_txtbox;
        private System.Windows.Forms.TextBox address_txtbox;
        private System.Windows.Forms.TextBox age_txtbox;
        private System.Windows.Forms.Label liscense_lbl;
        private System.Windows.Forms.RadioButton yes_rdobtn;
        private System.Windows.Forms.RadioButton no_rdobtn;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.GroupBox cartypebox;
        private System.Windows.Forms.RadioButton suv_rdobtn;
        private System.Windows.Forms.RadioButton sports_rdobtn;
        private System.Windows.Forms.RadioButton famcar_rdobtn;
        private System.Windows.Forms.RadioButton citycar_rdobtn;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.RadioButton electric_rdobtn;
        private System.Windows.Forms.RadioButton hybrid_rdobtn;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.RadioButton diesel_rdobtn;
        private System.Windows.Forms.RadioButton petrol_rdobtn;
        private System.Windows.Forms.Button clear_btn;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.Button Submitbtn;
        private System.Windows.Forms.Label lbladmin;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.CheckBox breakdowncheckbox;
    }
}