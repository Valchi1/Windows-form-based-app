﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VALCHI_CAR_RENTAL
{
    public partial class login : Form
    {
        public login()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {
            Application.Exit(); // code used to exit the software//
        }

        private void btnlogin_Click(object sender, EventArgs e) //Everything below is a condition to be met when login is clicked//
        {
            if (txtusername.Text == "sta001" && txtpassword.Text == "givemethekeys123")  //conditional statement for the username and password//
            {
                Home_Page goTo = new Home_Page();
                goTo.Show();
                this.Hide();
            }

            else
            {
                MessageBox.Show("invalid username or password");

            }
        }

        private void txtpassword_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtpassword_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
