﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;

namespace VALCHI_CAR_RENTAL
{
    class DBConfig
    {
        string name = "dbconnection";

        public string connection()
        {
            return ConfigurationManager.ConnectionStrings[name].ConnectionString;

        }
    }
}

