﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VALCHI_CAR_RENTAL
{
    public partial class summary : Form
    {
        public summary()
        {
            InitializeComponent();
        }

        private void summary_Load(object sender, EventArgs e)
        {
            CFN.Text = newbookings.CFN;
            CSN.Text = newbookings.CSN;
            CADDY.Text = newbookings.CADDY;
            CAGE.Text = newbookings.CAGE;
            VDL.Text = newbookings.VDL;
            NOD.Text = newbookings.NOD;
            CT.Text = newbookings.CT;
            FT.Text = newbookings.FT;
            OE.Text = newbookings.OE;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label15_Click(object sender, EventArgs e)
        {

        }

        private void proceedbtn_Click(object sender, EventArgs e)
        {
            models models = new models();
            string booktb;
            booktb = models.RegAccount(CFN.Text, CSN.Text, CADDY.Text,Convert.ToInt32(CAGE.Text), VDL.Text,Convert.ToInt32(NOD.Text), CT.Text, OE.Text, FT.Text);
            
            this.Hide();
            Home_Page finalbooking = new Home_Page();
            finalbooking.Show();

        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void OE_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }
    }
}
